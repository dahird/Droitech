'use client'
import React, { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Send, Mail, Phone, Workflow, GraduationCap, ClipboardList } from "lucide-react";

const brand = { red: "#ff1a1a" as const };
const CONTACT_ENDPOINT = "/api/contact";

const Section = ({ id, children, className = "" }: { id?: string; children: React.ReactNode; className?: string }) => (
  <section id={id} className={"scroll-mt-24 w-full max-w-7xl mx-auto px-4 md:px-8 " + className}>{children}</section>
);

export default function Page() {
  const [submitting, setSubmitting] = useState(false);
  const [status, setStatus] = useState<"idle" | "success" | "error">("idle");
  const [errorMsg, setErrorMsg] = useState("");

  const handleContactSubmit: React.FormEventHandler<HTMLFormElement> = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setStatus("idle");
    setErrorMsg("");
    const form = e.currentTarget;
    const data = new FormData(form);
    const payload = {
      name: String(data.get("name") || ""),
      email: String(data.get("email") || ""),
      company: String(data.get("company") || ""),
      role: String(data.get("role") || ""),
      message: String(data.get("message") || ""),
    };
    try {
      const res = await fetch(CONTACT_ENDPOINT, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      if (!res.ok) throw new Error("Bad response");
      setStatus("success");
      form.reset();
    } catch {
      const subject = encodeURIComponent("Inquiry from Droitech site");
      const body = encodeURIComponent(Object.entries(payload).map(([k, v]) => `${k}: ${v}`).join("\n"));
      window.location.href = "mailto:info@droitech.net?subject=" + subject + "&body=" + body;
      setStatus("success");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Top */}
      <div className="sticky top-0 z-50 border-b border-white/10 bg-black/80 backdrop-blur">
        <Section className="flex items-center justify-between py-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-md overflow-hidden bg-white flex items-center justify-center">
              <img src="/logo.png" alt="Droitech Consulting Logo" className="w-full h-full object-contain" />
            </div>
            <div className="font-semibold md:text-lg">Droitech Consulting</div>
          </div>
          <Button className="rounded-xl"><a href="#contact" className="flex items-center gap-2"><Send className="w-4 h-4" />Book a consult</a></Button>
        </Section>
      </div>

      {/* Hero */}
      <Section id="hero" className="pt-12 md:pt-24 pb-10">
        <div className="grid md:grid-cols-2 gap-10 items-center">
          <div>
            <h1 className="text-3xl md:text-5xl font-bold leading-tight">Agile Transformation for Regulated & Fast‑Growing Teams</h1>
            <p className="mt-4 text-white/80 md:text-lg max-w-xl">Modernization, training, and consulting—so you can ship value sooner without trading off security or quality.</p>
            <div className="mt-6 flex flex-wrap gap-2">
              <Badge>Enterprise Agile Coaching</Badge>
              <Badge>SAFe / Scrum / Kanban</Badge>
              <Badge>Portfolio & Program</Badge>
              <Badge>DevSecOps Enablement</Badge>
            </div>
            <div className="mt-8 flex items-center gap-3">
              <Button className="rounded-xl px-5 py-6 text-base"><a href="#services">Explore services</a></Button>
              <a href="/droitech-capability.pdf" download className="text-white/80 hover:text-white">Get a capability brief →</a>
            </div>
          </div>
          <div className="rounded-3xl overflow-hidden border border-white/10">
            <img src="/hero-1.jpg" alt="" aria-hidden="true" role="presentation" className="w-full h-full object-cover" />
          </div>
        </div>
      </Section>

      {/* Services */}
      <Section id="services" className="py-6 md:py-14">
        <h2 className="text-2xl md:text-4xl font-bold">What we do</h2>
        <p className="text-white/80 max-w-2xl mt-2">Three ways we help you move faster with confidence.</p>
        <div className="grid md:grid-cols-3 gap-5 mt-8">
          <Card className="bg-white/5 border-white/10 rounded-2xl">
            <CardHeader><CardTitle className="text-white flex gap-2 items-center"><Workflow className="w-5 h-5" /> Modernization</CardTitle></CardHeader>
            <CardContent className="text-white/80 text-sm space-y-2">
              <p>Operating model & portfolio redesign</p><p>DevSecOps enablement</p><p>Value stream mapping & flow</p>
            </CardContent>
          </Card>
          <Card className="bg-white/5 border-white/10 rounded-2xl">
            <CardHeader><CardTitle className="text-white flex gap-2 items-center"><GraduationCap className="w-5 h-5" /> Training</CardTitle></CardHeader>
            <CardContent className="text-white/80 text-sm space-y-2">
              <p>Role‑based bootcamps</p><p>Exec & manager workshops</p><p>Team launch & PI planning</p>
            </CardContent>
          </Card>
          <Card className="bg-white/5 border-white/10 rounded-2xl">
            <CardHeader><CardTitle className="text-white flex gap-2 items-center"><ClipboardList className="w-5 h-5" /> Consulting</CardTitle></CardHeader>
            <CardContent className="text-white/80 text-sm space-y-2">
              <p>Product strategy & OKRs</p><p>Risk & compliance in delivery</p><p>Metrics & coaching</p>
            </CardContent>
          </Card>
        </div>
      </Section>

      {/* Contact */}
      <Section id="contact" className="py-6 md:py-16">
        <div className="grid md:grid-cols-3 gap-8 items-stretch">
          <div className="md:col-span-2">
            <h2 className="text-2xl md:text-4xl font-bold">Let’s talk about your goals</h2>
            <p className="text-white/80 mt-2">Share a few details—our team will respond within one business day.</p>
            <form onSubmit={handleContactSubmit} className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input name="name" placeholder="Full name" required />
              <Input name="email" type="email" placeholder="Work email" required />
              <Input name="company" placeholder="Company" />
              <Input name="role" placeholder="Role" />
              <Textarea name="message" placeholder="What challenge are you solving?" className="md:col-span-2 min-h-[120px]" />
              <Button type="submit" disabled={submitting} className="md:col-span-2">{submitting ? "Sending…" : "Submit inquiry"}</Button>
              <div role="status" aria-live="polite" className="md:col-span-2 text-sm mt-2 text-white/80">{status === "success" ? "Thanks — we’ll reach out within one business day." : status === "error" ? errorMsg : ""}</div>
            </form>
          </div>
          <Card className="bg-white/5 border-white/10 rounded-2xl">
            <CardHeader><CardTitle className="text-white">Contact</CardTitle></CardHeader>
            <CardContent className="text-white/80 space-y-3 text-sm">
              <div className="flex items-center gap-2"><Mail className="w-4 h-4"/> info@droitech.net</div>
              <div className="flex items-center gap-2"><Phone className="w-4 h-4"/> 717-424-9308</div>
              <div className="pt-4">
                <a href="/droitech-capability.pdf" download className="block">
                  <Button className="w-full">Download capability statement (PDF)</Button>
                </a>
              </div>
            </CardContent>
          </Card>
        </div>
      </Section>

      {/* Footer */}
      <footer className="border-t border-white/10 py-8">
        <Section className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-white/60 text-sm">© {new Date().getFullYear()} Droitech Consulting. All rights reserved.</div>
          <div className="flex gap-4 text-white/60 text-sm">
            <a href="#" className="hover:text-white">Privacy</a>
            <a href="#" className="hover:text-white">Terms</a>
            <a href="#" className="hover:text-white">Security</a>
          </div>
        </Section>
      </footer>
    </div>
  );
}
