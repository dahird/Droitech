import { NextRequest, NextResponse } from 'next/server';
import nodemailer from 'nodemailer';

export async function POST(req: NextRequest) {
  try {
    const data = await req.json();
    const { name, email, company, role, message, userAgent, path } = data || {};
    if (!name || !email) {
      return NextResponse.json({ ok: false, error: 'Missing required fields' }, { status: 400 });
    }
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 465),
      secure: true,
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
    });
    const body = [
      `Name: ${name}`,
      `Email: ${email}`,
      `Company: ${company || ''}`,
      `Role: ${role || ''}`,
      `Message: ${message || ''}`,
      `UserAgent: ${userAgent || ''}`,
      `Path: ${path || ''}`,
    ].join('\n');
    await transporter.sendMail({
      from: `Droitech <${process.env.MAIL_FROM || 'info@droitech.net'}>`,
      to: process.env.MAIL_TO || 'info@droitech.net',
      subject: 'New inquiry from Droitech site',
      text: body,
    });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ ok: false, error: 'Server error' }, { status: 500 });
  }
}
