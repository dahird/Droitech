export const metadata={title:"Droitech Consulting",description:"Agile transformation, modernization, training, and consulting.",};
import "./globals.css";
export default function RootLayout({children}:{children:React.ReactNode}){return(<html lang="en"><body>{children}</body></html>)}
