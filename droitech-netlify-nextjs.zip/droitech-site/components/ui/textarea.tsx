'use client'
import * as React from 'react';
export function Textarea({className='',...props}:React.TextareaHTMLAttributes<HTMLTextAreaElement>){const base='w-full rounded-md border border-white/15 bg-white/10 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-white/20';return <textarea className={[base,className].join(' ')} {...props}/>}
export default Textarea;
