'use client'
import * as React from 'react';
export function Input({className='',...props}:React.InputHTMLAttributes<HTMLInputElement>){const base='w-full rounded-md border border-white/15 bg-white/10 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-white/20';return <input className={[base,className].join(' ')} {...props}/>}
export default Input;
