'use client'
import * as React from 'react';
export function Badge({className='',children}:any){const base='inline-flex items-center rounded-full px-2.5 py-1 text-xs';const theme='bg-white/10 border border-white/10 text-white/80';return <span className={[base,theme,className].join(' ')}>{children}</span>}
export default Badge;
