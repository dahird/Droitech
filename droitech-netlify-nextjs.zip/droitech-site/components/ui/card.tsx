'use client'
import * as React from 'react';
export function Card({className='',children}:{className?:string;children?:React.ReactNode}){return <div className={['rounded-xl border border-white/10 bg-white/5',className].join(' ')}>{children}</div>}
export function CardHeader({className='',children}:{className?:string;children?:React.ReactNode}){return <div className={['p-4',className].join(' ')}>{children}</div>}
export function CardContent({className='',children}:{className?:string;children?:React.ReactNode}){return <div className={['p-4 pt-0',className].join(' ')}>{children}</div>}
export function CardTitle({className='',children}:{className?:string;children?:React.ReactNode}){return <h3 className={['text-lg font-semibold',className].join(' ')}>{children}</h3>}
export default Card;
