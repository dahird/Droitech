'use client'
import * as React from 'react';
type Props=React.ButtonHTMLAttributes<HTMLButtonElement>&{variant?:'default'|'outline'};
export const Button=React.forwardRef<HTMLButtonElement,Props>(function Button({className='',variant='default',...props},ref){const base='inline-flex items-center justify-center px-3 py-2 text-sm font-medium rounded-md transition-colors';const theme=variant==='outline'?'border border-white/20 bg-transparent text-white hover:bg-white/10':'bg-[#ff1a1a] text-white hover:opacity-90';return <button ref={ref} className={[base,theme,className].join(' ')} {...props}/>});
export default Button;
