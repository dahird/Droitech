# Droitech Consulting — Next.js site (Netlify-ready)

**How to deploy (non-technical steps):**
1. Push this folder to GitHub as a new repo.
2. In Netlify: Add new site → Import from Git → pick the repo.
3. Keep defaults (Next.js detected) → Deploy.
4. In Netlify → Site settings → Domain management: connect your GoDaddy domain (follow the on-screen DNS steps).

**Optional (to make the form email you automatically):**
Add these Environment variables in Netlify:
- SMTP_HOST (e.g., smtpout.secureserver.net)
- SMTP_PORT (465 or 587)
- SMTP_USER (e.g., info@droitech.net)
- SMTP_PASS (password)
- MAIL_FROM = info@droitech.net
- MAIL_TO   = info@droitech.net

Trigger a redeploy to apply.

**Local dev**
```bash
npm install
npm run dev
```
